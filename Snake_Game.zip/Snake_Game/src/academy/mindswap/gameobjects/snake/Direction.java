package academy.mindswap.gameobjects.snake;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT;
}
